# Node Chat

A simple chat application in Node.js with no other dependencies.
Originally written by Ryan Dahl, the creator of Node.js.

## Local development

    node app.js

## Deploying to Stackato

    stackato push node-chat
